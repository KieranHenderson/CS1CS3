/**
 * @file course.c
 * @author Kieran Henderson (hendek12@mcmaster.ca)
 * @brief file which contains all the nessesary functions to manipulate and interact with the course type
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>

//function which adds a student to the course, takes a pointer to a Course and a pointer to a Student as parameters, returns nothing
void enroll_student(Course *course, Student *student)
{
  //increase the amount of Students in the Course by 1
  course->total_students++;

  //if the total Course previously had 0 Students then it is nessesary to use calloc to allocate memory for the new Student
  //but if there was already 1 or more Students in the Course then use realloc to reallocate more memory to the Course rather than using calloc to allocate brand new memory
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  //assgin the student to the new position in the Courses Student array
  course->students[course->total_students - 1] = *student;
}

//function which prints out all the information about the course, takes a pointer to a Course as a parameter, returns nothing
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) //loop through each Student in the Course and print it
    print_student(&course->students[i]);
}

//function which returns a pointer to the top student in the course, takes a Course as a parameter, returns a Student
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL; //if the Course has 0 Students enrolled in it there is no top student so return NULL
 
  double student_average = 0;
  double max_average = average(&course->students[0]); //current highest average to compare others to
  Student *student = &course->students[0];            //Student with the current highest average
 
  for (int i = 1; i < course->total_students; i++)  //loop through every Student in the class and compare their average to the Student with the current highest average (max_average)
  {                                                 
    student_average = average(&course->students[i]);
    if (student_average > max_average)              //if their average is higher than the the current highest average (max_average) then they become the the current highest average (max_average) instead
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

//function which returns a pointer to an array of the students who are passing the course, takes a Course and the amount of students passing the Course as parameters, returns a Student
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++; //loop through each student in the Course and if their average is above 50 then increment count by 1
  
  passing = calloc(count, sizeof(Student)); //assign memory to passing (array of Students) using calloc to allocate enough memory to hold the number of students who are passing the Course in an array

  int j = 0; //tracking the index of Students in the passing array
  //int i tracks the index of Students in the array of all Students
  for (int i = 0; i < course->total_students; i++) //loop through each student in the Course and if their average >= 50 then add them to the array of passing students 
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count; //update the amount of students who are passing

  return passing;
}