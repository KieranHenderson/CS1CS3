var searchData=
[
  ['student_2ec_5',['student.c',['../student_8c.html',1,'']]],
  ['student_2eh_6',['student.h',['../student_8h.html',1,'']]]
];
