/**
 * @file course.h
 * @author Kieran Henderson (hendek12@mcmaster.ca)
 * @brief file which contains the type declarations and function declarations for the course.c file
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>

// typedef which defines the student data type 
typedef struct _course 
{
  char name[100];     //name of the course
  char code[10];      //code of the course
  Student *students;  //array of students enrolled in the course 
  int total_students; //number of students in the course
} Course;

void enroll_student(Course *course, Student *student);  //function which adds a student to the course, takes a pointer to a Course and a pointer to a Student as parameters, returns nothing
void print_course(Course *course);                      //function which prints out all the information about the course, takes a pointer to a Course as a parameter, returns nothing
Student *top_student(Course* course);                   //function which returns a pointer to the top student in the course, takes a Course as a parameter, returns a Student
Student *passing(Course* course, int *total_passing);   //function which returns a pointer to an array of the students who are passing the course, takes a Course and the amount of students passing the Course as parameters, returns a Student


