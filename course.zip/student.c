/**
 * @file student.c
 * @author Kieran Henderson (hendek12@mcmaster.ca)
 * @brief file which contains all the nessesary functions to manipulate and interact with the student type
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

//function which adds a grade to a Student, takes a pointer to a Student and a grade as parameters, returns nothing
void add_grade(Student* student, double grade)
{ 
  //increase the number of grades the student has by 1
  student->num_grades++;

  //if the student previously had 0 grades then it is nessesary to use calloc to allocate memory for the grade
  //but if there was already 1 or more grades in the student then use realloc to reallocate more memory to the grades rather than using calloc to allocate brand new memory
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  //assign the grade to the new position in the students array of grades
  student->grades[student->num_grades - 1] = grade;
}

//function which finds a Students average grade in the course, takes a pointer to a Student as a parameter, returns the average as a double
double average(Student* student)
{
  if (student->num_grades == 0) return 0; //if the student has no grades then their average is 0

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i]; //loop through all the students grades and add them together 
  return total / ((double) student->num_grades); //return the sum of the students grades divided by the number of grades they have
}

//function which prints out a Students information, takes a pointer to a Student as a parameter, returns nothing
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name); 
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) //loop through each grade in the Student and print it
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student)); //print the Students average
}

//function which returns a random Student from a list of names and gernerates as many random grades as the parameter, takes a int (grade) as a parameter, returns a student
Student* generate_random_student(int grades)
{
  //array of possible first names
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  //array of possible last names
  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  //assign the student a random first name and last name from the list of possible names 
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  //generate a random student id for the Student that is 10 characters long 
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75))); //add as many grades as the parameter indicates to the student 
  }

  return new_student;
}