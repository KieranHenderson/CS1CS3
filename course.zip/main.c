/**
 * @file main.c
 * @author Kieran Henderson (hendek12@mcmaster.ca)
 * @brief program which creates a course object for the course MATH101 and randomly generates 20 students for the course along with 8 random grades for each students 
          and then prints out the course with each student enrolled and their information, the top student, and an array of all students who are passinbg the class
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

int main()
{
  //seeds the random number generator used by the rand function
  srand((unsigned) time(NULL));

  //allocate memory for a single course 
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //gernerate 20 new students each with 8 grades in the class
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  //print the name of the course, course code, total students 
  //then each student with their name, id, grades, and average
  print_course(MATH101);

  //call top_student to loop through each student in the class to find the one with the highest overall average and store that student in the student object then print it
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //get and print all the students who are passing
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}