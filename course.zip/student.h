/**
 * @file student.h
 * @author Kieran Henderson (hendek12@mcmaster.ca)
 * @brief file which contains the type declarations and function declarations for the student.c file
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */

// typedef which defines the Student data type 
typedef struct _student 
{ 
  char first_name[50];  //first name of the Student
  char last_name[50];   //last name of the Student 
  char id[11];          //id of the Student
  double *grades;       //array containing all the Students grades for a given course
  int num_grades;       //number of grades the Student has in a given class
} Student;

void add_grade(Student *student, double grade); //function which adds a grade to a Student, takes a pointer to a Student and a grade as parameters, returns nothing
double average(Student *student);               //function which finds a Students average grade in the course, takes a pointer to a Student as a parameter, returns the average as a double
void print_student(Student *student);           //function which prints out a Students information, takes a pointer to a Student as a parameter, returns nothing
Student* generate_random_student(int grades);   //function which returns a random Student from a list of names and gernerates as many random grades as the parameter, takes a int (grade) as a parameter, returns a student
